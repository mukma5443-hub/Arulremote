plugins {
    id("com.android.application")
}

android {
    namespace = "com.arul.remote"
    compileSdk = 37

    defaultConfig {
        applicationId = "com.arul.remote"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "1.2-direct-adb"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.activity:activity-ktx:1.10.0")
    implementation("com.flyfishxu:kadb:1.2.1")
}
