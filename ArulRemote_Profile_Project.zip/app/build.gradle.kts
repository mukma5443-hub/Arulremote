plugins {
    id("com.android.application")
}
android {
    namespace = "com.arul.remote"
    compileSdk = 37
    defaultConfig {
        applicationId = "com.arul.remote"
        minSdk = 26
        targetSdk = 35
        versionCode = 6
        versionName = "1.6"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.activity:activity-ktx:1.10.0")
    // Direct ADB client: no Termux and no adb executable required
    implementation("com.flyfishxu:kadb:2.1.4")
    implementation("org.jetbrains.kotlin:kotlin-stdlib:2.2.0")
}


configurations.configureEach {
    resolutionStrategy.force(
        "org.jetbrains.kotlin:kotlin-stdlib:2.2.0",
        "org.jetbrains.kotlin:kotlin-stdlib-jdk7:2.2.0",
        "org.jetbrains.kotlin:kotlin-stdlib-jdk8:2.2.0"
    )
}
