# ArulShell FIX 6.1

Perubahan dibanding FIX 6:
- Identitas RSA host dibuat sekali dan disimpan di app-private storage.
- Reconnect memakai identitas RSA yang sama.
- Ada transport TCP ADB dasar.
- Tidak ada bypass terhadap dialog RSA pertama.
- Project ini BELUM mengklaim shell-v2 penuh; encoding AUTH/public-key ADB harus diselesaikan dan diuji terhadap Android target sebelum APK disebut final.

Target perilaku:
Pertama kali -> RSA Allow/Always Allow -> koneksi.
Berikutnya -> gunakan identity yang sama -> reconnect tanpa dialog RSA baru, selama Android masih mempercayai identity tersebut.
