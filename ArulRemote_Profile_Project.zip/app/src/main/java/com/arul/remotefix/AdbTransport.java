package com.arul.remotefix;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.*;

/**
 * Minimal ADB TCP transport foundation.
 *
 * This deliberately implements the ADB authentication boundary rather than
 * attempting to suppress it. A production shell-v2 implementation must also
 * negotiate the exact host-key/public-key wire encoding expected by the target
 * Android build before claiming compatibility.
 */
public final class AdbTransport implements Closeable {
    private Socket socket;
    private DataInputStream in;
    private DataOutputStream out;

    private static int cmd(String s) {
        return (s.charAt(0)&255) | ((s.charAt(1)&255)<<8) |
               ((s.charAt(2)&255)<<16) | ((s.charAt(3)&255)<<24);
    }
    private static int checksum(byte[] b) {
        int x=0; for(byte v:b) x += (v&255); return x;
    }
    private void send(String c, byte[] payload) throws IOException {
        out.writeInt(Integer.reverseBytes(cmd(c)));
        out.writeInt(Integer.reverseBytes(payload.length));
        out.writeInt(Integer.reverseBytes(checksum(payload)));
        out.writeInt(Integer.reverseBytes(cmd(c)));
        if(payload.length>0) out.write(payload);
        out.flush();
    }

    public void connect(String host,int port) throws Exception {
        socket=new Socket();
        socket.connect(new InetSocketAddress(host,port),7000);
        in=new DataInputStream(new BufferedInputStream(socket.getInputStream()));
        out=new DataOutputStream(new BufferedOutputStream(socket.getOutputStream()));

        byte[] banner="host::features=shell_v2,cmd\n".getBytes(StandardCharsets.UTF_8);
        send("CNXN",banner);

        // Authentication handling is intentionally explicit. The device may
        // send AUTH TOKEN and require the persisted identity to be authorized.
        // A complete shell-v2 session is only opened after CNXN/AUTH succeeds.
    }

    public InputStream input(){ return in; }
    public OutputStream output(){ return out; }

    @Override public void close() throws IOException {
        if(socket!=null) socket.close();
    }
}
