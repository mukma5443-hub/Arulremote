package com.arul.remote

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.flyfishxu.kadb.Kadb

class MainActivity : AppCompatActivity() {

    private lateinit var output: TextView
    private lateinit var input: EditText
    private lateinit var runButton: Button
    private lateinit var sendButton: Button

    @Volatile private var host: String? = null
    @Volatile private var port: Int = 5555

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        output = findViewById(R.id.output)
        input = findViewById(R.id.input)
        runButton = findViewById(R.id.runButton)
        sendButton = findViewById(R.id.rootButton)

        // Force the buttons to remain usable.
        runButton.isEnabled = true
        runButton.isClickable = true
        sendButton.isEnabled = true
        sendButton.isClickable = true

        output.text = buildString {
            append("Arul Remote\n")
            append("Direct ADB mode — no sh / Termux / adb binary.\n")
            append("Kadb direct client.\n\n")
            append("Masukkan contoh:\n")
            append("adb connect 172.20.10.2:5555\n")
        }

        runButton.setOnClickListener {
            execute(input.text.toString())
        }

        sendButton.setOnClickListener {
            executeShell(input.text.toString())
        }

        findViewById<Button>(R.id.clearButton).setOnClickListener {
            output.text = ""
        }
    }

    private fun execute(raw: String) {
        val command = raw.trim()
        if (command.isBlank()) {
            append("Masukkan perintah terlebih dahulu.\n")
            return
        }

        val match = Regex(
            """^(?:adb\s+)?connect\s+([0-9A-Za-z.\-]+):(\d+)\s*$""",
            RegexOption.IGNORE_CASE
        ).find(command)

        if (match == null) {
            append("Format connect salah.\nContoh: adb connect 172.20.10.2:5555\n")
            return
        }

        val h = match.groupValues[1]
        val p = match.groupValues[2].toIntOrNull()

        if (p == null || p !in 1..65535) {
            append("Port tidak valid.\n")
            return
        }

        setBusy(true)
        append("Mencoba koneksi langsung ke $h:$p ...\n")

        Thread {
            try {
                Kadb.create(h, p).use { adb ->
                    val response = adb.shell("echo ARUL_REMOTE_CONNECTED")
                    if (response.exitCode == 0) {
                        host = h
                        port = p
                        append("CONNECTED: $h:$p\n")
                        append("Direct ADB berhasil. Tidak memakai sh/Termux/adb binary.\n")
                    } else {
                        append("Koneksi terbuka tetapi shell gagal.\n")
                        append(response.output)
                        if (!response.output.endsWith("\n")) append("\n")
                        append("exit code: ${response.exitCode}\n")
                    }
                }
            } catch (e: Exception) {
                append("CONNECT FAILED: ${e.javaClass.simpleName}: ${e.message ?: "unknown error"}\n")
                append("Pastikan HP target mengaktifkan ADB/Wireless debugging dan IP:PORT benar.\n")
            } finally {
                setBusy(false)
            }
        }.start()
    }

    private fun executeShell(raw: String) {
        val command = raw.trim()
        if (command.isBlank()) {
            append("Masukkan perintah shell.\n")
            return
        }

        val h = host
        if (h == null) {
            append("Belum terhubung. Jalankan dulu: adb connect IP:PORT\n")
            return
        }

        val actual = command
            .removePrefix("adb shell ")
            .removePrefix("adb shell")
            .trim()

        if (actual.isBlank()) {
            append("Contoh: getprop ro.product.model\n")
            return
        }

        setBusy(true)
        Thread {
            try {
                Kadb.create(h, port).use { adb ->
                    val response = adb.shell(actual)
                    append(response.output)
                    if (response.exitCode != 0) {
                        append("exit code: ${response.exitCode}\n")
                    }
                }
            } catch (e: Exception) {
                append("ADB SHELL ERROR: ${e.javaClass.simpleName}: ${e.message ?: "unknown error"}\n")
            } finally {
                setBusy(false)
            }
        }.start()
    }

    private fun setBusy(busy: Boolean) {
        runOnUiThread {
            runButton.isEnabled = !busy
            sendButton.isEnabled = !busy
            if (!busy) {
                runButton.isClickable = true
                sendButton.isClickable = true
            }
        }
    }

    private fun append(text: String) {
        runOnUiThread {
            output.append(text)
        }
    }
}
