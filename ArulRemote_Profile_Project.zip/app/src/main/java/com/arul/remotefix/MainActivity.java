package com.arul.remotefix;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.widget.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    EditText ip,port;
    TextView log;
    ExecutorService pool=Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        LinearLayout l=new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(24,24,24,24);

        TextView t=new TextView(this);
        t.setText("ArulShell FIX 6.1\n1× RSA Allow → reuse identity on reconnect");
        t.setTextSize(21); t.setTextColor(Color.WHITE);
        t.setPadding(12,12,12,12);
        t.setBackgroundColor(Color.rgb(25,25,25));
        l.addView(t);

        ip=new EditText(this); ip.setHint("IP HP"); l.addView(ip);
        port=new EditText(this); port.setText("5555"); l.addView(port);

        Button b1=new Button(this); b1.setText("CONNECT"); l.addView(b1);

        log=new TextView(this);
        log.setTextIsSelectable(true);
        ScrollView s=new ScrollView(this); s.addView(log);
        l.addView(s,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(l);

        b1.setOnClickListener(v -> connect());
    }

    void connect(){
        final String h=ip.getText().toString().trim();
        final int p=Integer.parseInt(port.getText().toString().trim());
        if(h.isEmpty()){ log.setText("Masukkan IP HP."); return; }

        pool.execute(() -> {
            try{
                AdbIdentity id=AdbIdentity.loadOrCreate(this);
                log("Identitas RSA aplikasi: tersedia (dipakai ulang pada reconnect).");
                AdbTransport a=new AdbTransport();
                a.connect(h,p);
                log("TCP ADB tersambung ke "+h+":"+p+".");
                log("Jika ini adalah otorisasi pertama, Android tetap dapat menampilkan RSA Allow.");
                log("Setelah host identity dipercaya, koneksi berikutnya menggunakan identity yang sama.");
                log("Catatan: shell-v2 penuh belum dinyatakan kompatibel sampai AUTH/public-key wire encoding selesai.");
            }catch(Exception e){ log("Gagal: "+e.getMessage()); }
        });
    }

    void log(String x){ runOnUiThread(() -> log.append(x+"\n")); }
}
