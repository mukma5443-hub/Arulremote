Arul Remote Direct ADB v1.4 BUILD FIX

This build removes Kotlin/Kadb compilation from the app. The app is now a Java Android app and implements the basic ADB TCP protocol directly over a Socket. It does not execute sh, Termux, or an adb binary.

Why: the previous build failed at :app:compileDebugKotlin. This version contains no Kotlin source and no Kadb dependency, avoiding that compiler/dependency mismatch.

Usage:
1. Build the APK with the existing GitHub Actions workflow.
2. On the target device enable ADB over TCP / Wireless debugging as applicable.
3. Enter: adb connect IP:PORT
4. Press Run.

Important: Android 11+ Wireless debugging normally uses authenticated TLS and pairing. A legacy plain TCP 5555 endpoint must be available for this minimal direct protocol client. The app reports an explicit error if the target requests ADB authentication.
