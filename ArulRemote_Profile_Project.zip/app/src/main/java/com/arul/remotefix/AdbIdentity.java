package com.arul.remotefix;

import android.content.Context;
import java.io.*;
import java.security.*;
import java.util.Base64;

/**
 * Persistent ADB host identity.
 *
 * The key is generated once and kept in app-private storage. Reconnects reuse
 * the same identity. The first authorization still belongs to Android/ADB.
 */
public final class AdbIdentity {
    private final KeyPair pair;
    private final File dir;

    private AdbIdentity(KeyPair p, File d) { pair=p; dir=d; }

    public static AdbIdentity loadOrCreate(Context c) throws Exception {
        File d=new File(c.getFilesDir(),"adb_identity");
        if(!d.exists() && !d.mkdirs()) throw new IOException("Cannot create identity dir");
        File priv=new File(d,"private.key");
        KeyPair kp;
        if(priv.exists()) {
            try(ObjectInputStream in=new ObjectInputStream(new FileInputStream(priv))) {
                PrivateKey sk=(PrivateKey)in.readObject();
                PublicKey pk=(PublicKey)in.readObject();
                kp=new KeyPair(pk,sk);
            }
        } else {
            KeyPairGenerator g=KeyPairGenerator.getInstance("RSA");
            g.initialize(2048);
            kp=g.generateKeyPair();
            try(ObjectOutputStream out=new ObjectOutputStream(new FileOutputStream(priv))) {
                out.writeObject(kp.getPrivate());
                out.writeObject(kp.getPublic());
            }
        }
        return new AdbIdentity(kp,d);
    }

    public KeyPair keyPair(){ return pair; }

    public byte[] sign(byte[] token) throws Exception {
        Signature s=Signature.getInstance("SHA1withRSA");
        s.initSign(pair.getPrivate());
        s.update(token);
        return s.sign();
    }

    /**
     * ADB expects an RSA public-key structure followed by a user name.
     * The exact wire encoding is handled by AdbTransport.
     */
    public PublicKey publicKey(){ return pair.getPublic(); }
}
