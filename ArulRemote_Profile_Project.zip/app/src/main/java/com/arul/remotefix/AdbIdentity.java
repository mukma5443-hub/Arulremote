package com.arul.remotefix;

import android.content.Context;
import java.io.*;
import java.math.BigInteger;
import java.security.*;
import java.security.interfaces.RSAPublicKey;
import java.util.Base64;

/** Persistent RSA-2048 host identity used by ADB AUTH. */
public final class AdbIdentity {
    private final KeyPair pair;

    private AdbIdentity(KeyPair p) { pair = p; }

    public static AdbIdentity loadOrCreate(Context c) throws Exception {
        File dir = new File(c.getFilesDir(), "adb_identity");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Cannot create identity dir");
        File priv = new File(dir, "private.key");
        KeyPair kp;
        if (priv.exists()) {
            try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(priv))) {
                PrivateKey sk = (PrivateKey) in.readObject();
                PublicKey pk = (PublicKey) in.readObject();
                kp = new KeyPair(pk, sk);
            } catch (Exception badKey) {
                // A corrupted/old app-private key should not brick reconnects.
                if (!priv.delete()) throw badKey;
                kp = generateAndSave(priv);
            }
        } else {
            kp = generateAndSave(priv);
        }
        return new AdbIdentity(kp);
    }

    private static KeyPair generateAndSave(File file) throws Exception {
        KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");
        g.initialize(2048);
        KeyPair kp = g.generateKeyPair();
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(file))) {
            out.writeObject(kp.getPrivate());
            out.writeObject(kp.getPublic());
        }
        return kp;
    }

    public byte[] sign(byte[] token) throws Exception {
        if (token.length != 20) throw new GeneralSecurityException("Unexpected ADB token length");
        Signature s = Signature.getInstance("SHA1withRSA");
        s.initSign(pair.getPrivate());
        s.update(token);
        return s.sign();
    }

    /**
     * Android ADB public-key wire format: 524-byte binary RSA structure,
     * base64 encoded, followed by a space, name and NUL terminator.
     */
    public byte[] publicKeyWire() throws Exception {
        RSAPublicKey r = (RSAPublicKey) pair.getPublic();
        if (r.getModulus().bitLength() > 2048) {
            throw new GeneralSecurityException("Only RSA-2048 ADB keys are supported");
        }

        final int words = 64;
        final BigInteger two32 = BigInteger.ONE.shiftLeft(32);
        final BigInteger mask32 = two32.subtract(BigInteger.ONE);
        final BigInteger n = r.getModulus();
        final BigInteger e = r.getPublicExponent();

        // n0inv = -1 / N[0] mod 2^32.
        BigInteger n0 = n.and(mask32);
        BigInteger n0inv = n0.modInverse(two32).negate().and(mask32);

        // rr = R^2 mod N, where R = 2^2048.
        BigInteger R = BigInteger.ONE.shiftLeft(2048);
        BigInteger rr = R.multiply(R).mod(n);

        ByteArrayOutputStream raw = new ByteArrayOutputStream(524);
        writeLE32(raw, words);
        writeLE32(raw, n0inv.longValue());
        writeWordsLE(raw, n, words);
        writeWordsLE(raw, rr, words);
        writeLE32(raw, e.longValue());

        String b64 = Base64.getEncoder().encodeToString(raw.toByteArray());
        return (b64 + " arulshell@android\0").getBytes("US-ASCII");
    }

    private static void writeWordsLE(OutputStream out, BigInteger value, int words) throws IOException {
        BigInteger mask = BigInteger.ONE.shiftLeft(32).subtract(BigInteger.ONE);
        BigInteger x = value;
        for (int i = 0; i < words; i++) {
            writeLE32(out, x.and(mask).longValue());
            x = x.shiftRight(32);
        }
    }

    private static void writeLE32(OutputStream out, long value) throws IOException {
        out.write((int) value & 0xff);
        out.write((int) (value >>> 8) & 0xff);
        out.write((int) (value >>> 16) & 0xff);
        out.write((int) (value >>> 24) & 0xff);
    }
}
