# Arul Remote v1.2

This version uses `com.flyfishxu:kadb-android:2.1.4` as a direct ADB client.
It can connect to an existing ADB-over-TCP transport without installing Termux
or `android-tools`.

Examples inside the app:
- `adb connect 192.168.1.8:5555`
- `adb shell getprop ro.product.model`
- `adb shell settings get system screen_brightness`

Important: the target device still needs Wireless debugging / ADB-over-network
enabled and authorized. USB debugging being enabled by itself does not make
port 5555 listen.
