package com.arul.shell;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import io.github.muntashirakon.adb.AbsAdbConnectionManager;
import io.github.muntashirakon.adb.AdbStream;
import java.io.*;
import java.math.BigInteger;
import java.security.*;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.*;
import java.util.concurrent.*;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.DERGeneralString;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x509.Extension;
import org.bouncycastle.asn1.x509.PrivateKeyUsagePeriod;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.cert.jcajce.JcaX509ExtensionUtils;
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;

public class MainActivity extends AppCompatActivity {
    private TextView terminal; private EditText input; private final ExecutorService pool=Executors.newCachedThreadPool();
    private AdbManager adb; private boolean remoteShell=false; private final ArrayList<String> history=new ArrayList<>(); private int historyPos=-1;
    private final int green=Color.rgb(190,255,190), white=Color.rgb(235,235,235);

    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.BLACK);getWindow().setNavigationBarColor(Color.BLACK);adb=new AdbManager();buildUi();
        print("Welcome to ArulShell!");print("");print("ArulShell terminal — Alpine-style interface");print("ADB is built into the app: no Termux, no pkg update, no android-tools.");print("Type 'help' for commands.");prompt();}
    private TextView makeTerminal(){TextView t=new TextView(this);t.setTextColor(white);t.setTextSize(14);t.setTypeface(Typeface.MONOSPACE);t.setPadding(14,14,14,14);t.setTextIsSelectable(true);return t;}
    private void buildUi(){LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.BLACK);terminal=makeTerminal();ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.addView(terminal);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(8,4,8,8);bar.setBackgroundColor(Color.BLACK);TextView p=new TextView(this);p.setText("$ ");p.setTextColor(green);p.setTextSize(16);p.setTypeface(Typeface.MONOSPACE,Typeface.BOLD);bar.addView(p,new LinearLayout.LayoutParams(-2,54));
        input=new EditText(this);input.setSingleLine(true);input.setTextColor(white);input.setHintTextColor(Color.DKGRAY);input.setHint("command");input.setTextSize(15);input.setTypeface(Typeface.MONOSPACE);input.setBackgroundColor(Color.rgb(12,12,12));input.setPadding(10,0,10,0);input.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);input.setImeOptions(EditorInfo.IME_ACTION_DONE);bar.addView(input,new LinearLayout.LayoutParams(0,54,1));
        Button send=new Button(this);send.setText("↵");send.setTextSize(18);send.setAllCaps(false);bar.addView(send,new LinearLayout.LayoutParams(64,54));root.addView(bar);
        input.setOnEditorActionListener((v,id,e)->{if(id==EditorInfo.IME_ACTION_DONE||(e!=null&&e.getKeyCode()==KeyEvent.KEYCODE_ENTER)){executeLine();return true;}return false;});
        input.setOnKeyListener((v,key,e)->{if(e.getAction()==KeyEvent.ACTION_DOWN&&key==KeyEvent.KEYCODE_DPAD_UP){previousHistory();return true;}if(e.getAction()==KeyEvent.ACTION_DOWN&&key==KeyEvent.KEYCODE_DPAD_DOWN){nextHistory();return true;}return false;});send.setOnClickListener(v->executeLine());setContentView(root);}
    private void print(String s){runOnUiThread(()->{terminal.append(s+"\n");View p=terminal.getParent();if(p instanceof ScrollView)((ScrollView)p).post(()->((ScrollView)p).fullScroll(View.FOCUS_DOWN));});}
    private void prompt(){print(remoteShell?"Infinix-X6895B:/ $":"localhost:~$ ");}
    private void executeLine(){String line=input.getText().toString().trim();input.setText("");if(line.isEmpty()){prompt();return;}history.add(line);historyPos=history.size();print((remoteShell?"Infinix-X6895B:/ $ ":"localhost:~$ ")+line);pool.execute(()->dispatch(line));}
    private void dispatch(String line){String[] a=split(line);if(a.length==0){prompt();return;}String cmd=a[0];try{
        if(cmd.equals("help")){print("Commands:");print("  adb connect IP:PORT");print("  adb pair IP:PAIR_PORT CODE");print("  adb shell");print("  adb shell COMMAND");print("  exit / clear / history");print("  pwd / ls / id / uname");prompt();return;}
        if(cmd.equals("clear")){runOnUiThread(()->terminal.setText(""));prompt();return;} if(cmd.equals("history")){for(int i=0;i<history.size();i++)print((i+1)+"  "+history.get(i));prompt();return;} if(cmd.equals("exit")){remoteShell=false;print("exit");prompt();return;}
        if(cmd.equals("adb")&&a.length>=2){if(a[1].equals("connect")&&a.length>=3){adbConnect(a[2]);return;}if(a[1].equals("pair")&&a.length>=4){adbPair(a[2],a[3]);return;}if(a[1].equals("shell")){if(a.length==2){remoteShell=true;print("Entering ADB shell. Type 'exit' to return.");prompt();}else runRemote(joinFrom(a,2));return;}}
        if(remoteShell){runRemote(line);return;}runLocal(a);
    }catch(Throwable t){print("error: "+safe(t.getMessage()));prompt();}}
    private void adbConnect(String ep){String[] hp=ep.split(":",2);if(hp.length!=2){print("usage: adb connect IP:PORT");prompt();return;}try{boolean ok=adb.connect(hp[0],Integer.parseInt(hp[1]));print(ok?"connected to "+ep:"failed to connect to "+ep);}catch(Throwable t){print("connect error: "+safe(t.getMessage()));}prompt();}
    private void adbPair(String ep,String code){String[] hp=ep.split(":",2);if(hp.length!=2||code.length()!=6){print("usage: adb pair IP:PAIR_PORT CODE");prompt();return;}try{boolean ok=adb.pair(hp[0],Integer.parseInt(hp[1]),code);print(ok?"Successfully paired to "+ep:"pairing failed");}catch(Throwable t){print("pairing error: "+safe(t.getMessage()));}prompt();}
    private void runRemote(String command){try{AdbStream s=adb.openStream("shell:"+command);try(BufferedReader r=new BufferedReader(new InputStreamReader(s.openInputStream()))){String line;while((line=r.readLine())!=null)print(line);}s.close();}catch(Throwable t){print("ADB shell error: "+safe(t.getMessage()));}prompt();}
    private void runLocal(String[] args){if(args[0].equals("cd")){print("ArulShell: cd is available only as a UI path placeholder; use adb shell for device paths.");prompt();return;}try{Process p=new ProcessBuilder(args).redirectErrorStream(true).start();try(BufferedReader r=new BufferedReader(new InputStreamReader(p.getInputStream()))){String line;while((line=r.readLine())!=null)print(line);}p.waitFor();}catch(Throwable t){print(args[0]+": command not found or not permitted");}prompt();}
    private String[] split(String s){ArrayList<String> out=new ArrayList<>();java.util.regex.Matcher m=java.util.regex.Pattern.compile("(?:[^\\s\\\"]|\\\"[^\\\"]*\\\")+").matcher(s);while(m.find()){String x=m.group();if(x.startsWith("\"")&&x.endsWith("\""))x=x.substring(1,x.length()-1);out.add(x);}return out.toArray(new String[0]);}
    private String joinFrom(String[] a,int start){StringBuilder b=new StringBuilder();for(int i=start;i<a.length;i++){if(i>start)b.append(' ');b.append(a[i]);}return b.toString();} private String safe(String s){return s==null?"unknown error":s;}
    private void previousHistory(){if(history.isEmpty())return;historyPos=Math.max(0,historyPos-1);input.setText(history.get(historyPos));input.setSelection(input.length());} private void nextHistory(){if(history.isEmpty())return;historyPos=Math.min(history.size(),historyPos+1);input.setText(historyPos<history.size()?history.get(historyPos):"");input.setSelection(input.length());}
    @Override protected void onDestroy(){pool.shutdownNow();try{adb.close();}catch(Exception ignored){}super.onDestroy();}

    private class AdbManager extends AbsAdbConnectionManager {
        private PrivateKey key; private Certificate cert; private final File dir;
        AdbManager(){dir=new File(getFilesDir(),"adb_identity");try{setApi(Build.VERSION.SDK_INT);loadOrCreate();}catch(Exception e){print("identity error: "+e.getMessage());}}
        private byte[] read(File f)throws Exception{try(FileInputStream in=new FileInputStream(f);ByteArrayOutputStream o=new ByteArrayOutputStream()){byte[] b=new byte[4096];int n;while((n=in.read(b))>0)o.write(b,0,n);return o.toByteArray();}}
        private void write(File f,byte[] b)throws Exception{try(FileOutputStream o=new FileOutputStream(f)){o.write(b);}}
        private void loadOrCreate()throws Exception{File kf=new File(dir,"key.der"),cf=new File(dir,"cert.der");if(kf.exists()&&cf.exists()){key=KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(read(kf)));cert=CertificateFactory.getInstance("X.509").generateCertificate(new ByteArrayInputStream(read(cf)));return;}
            dir.mkdirs();KeyPairGenerator g=KeyPairGenerator.getInstance("RSA");g.initialize(2048,new SecureRandom());KeyPair kp=g.generateKeyPair();key=kp.getPrivate();PublicKey pub=kp.getPublic();Date from=new Date(System.currentTimeMillis()-60000);Date to=new Date(System.currentTimeMillis()+31536000000L);X500Name name=new X500Name("CN=ArulShell");
            JcaX509v3CertificateBuilder builder=new JcaX509v3CertificateBuilder(name,BigInteger.valueOf(Math.abs(new Random().nextInt())+1L),from,to,name,pub);JcaX509ExtensionUtils ext=new JcaX509ExtensionUtils();builder.addExtension(Extension.subjectKeyIdentifier,false,ext.createSubjectKeyIdentifier(pub));
            ContentSigner signer=new JcaContentSignerBuilder("SHA512withRSA").build(key);cert=new JcaX509CertificateConverter().getCertificate(builder.build(signer));write(kf,key.getEncoded());write(cf,cert.getEncoded());}
        @Override protected PrivateKey getPrivateKey(){return key;} @Override protected Certificate getCertificate(){return cert;} @Override protected String getDeviceName(){return "ArulShell";}
    }
}
