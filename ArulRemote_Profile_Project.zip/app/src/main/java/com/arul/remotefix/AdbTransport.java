package com.arul.remotefix;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;

/** Direct ADB TCP host transport with a persistent shell,v2,pty session. */
public final class AdbTransport implements Closeable {
    private static final int A_CNXN = 0x4e584e43;
    private static final int A_OPEN = 0x4e45504f;
    private static final int A_OKAY = 0x59414b4f;
    private static final int A_CLSE = 0x45534c43;
    private static final int A_WRTE = 0x45545257;
    private static final int A_AUTH = 0x48545541;
    private static final int A_VERSION = 0x01000001;
    private static final int MAX_PAYLOAD = 1024 * 1024;
    private static final int AUTH_TIMEOUT_MS = 120_000;
    private static final int SHELL_STDIN = 0;
    private static final int SHELL_STDOUT = 1;
    private static final int SHELL_STDERR = 2;
    private static final int SHELL_EXIT = 3;

    private Socket socket;
    private DataInputStream in;
    private DataOutputStream out;
    private int localId = 1;
    private int remoteId;
    private volatile boolean shellOpen;
    private volatile boolean writeReady;
    private Thread readerThread;
    private ShellListener listener;

    public interface ShellListener {
        void onOutput(String text);
        void onError(String text);
        void onClosed();
    }

    private static int checksum(byte[] b) {
        int x = 0;
        for (byte v : b) x += v & 0xff;
        return x;
    }

    private static String commandName(int c) {
        char[] x = new char[4];
        x[0] = (char) (c & 255);
        x[1] = (char) ((c >>> 8) & 255);
        x[2] = (char) ((c >>> 16) & 255);
        x[3] = (char) ((c >>> 24) & 255);
        return new String(x);
    }

    private void writeIntLE(int v) throws IOException {
        out.write(v & 255);
        out.write((v >>> 8) & 255);
        out.write((v >>> 16) & 255);
        out.write((v >>> 24) & 255);
    }

    private int readIntLE() throws IOException {
        int a = in.readUnsignedByte();
        int b = in.readUnsignedByte();
        int c = in.readUnsignedByte();
        int d = in.readUnsignedByte();
        return a | (b << 8) | (c << 16) | (d << 24);
    }

    private synchronized void send(int cmd, int arg0, int arg1, byte[] payload) throws IOException {
        if (payload == null) payload = new byte[0];
        if (payload.length > MAX_PAYLOAD) throw new IOException("ADB payload too large");
        writeIntLE(cmd);
        writeIntLE(arg0);
        writeIntLE(arg1);
        writeIntLE(payload.length);
        writeIntLE(0); // ADB protocol 0x01000001: checksum is skipped.
        writeIntLE(cmd ^ 0xffffffff);
        if (payload.length != 0) out.write(payload);
        out.flush();
    }

    private Packet readPacket() throws IOException {
        int cmd = readIntLE();
        int arg0 = readIntLE();
        int arg1 = readIntLE();
        int len = readIntLE();
        int sum = readIntLE();
        int magic = readIntLE();
        if ((cmd ^ 0xffffffff) != magic) throw new IOException("Bad ADB magic for " + commandName(cmd));
        if (len < 0 || len > MAX_PAYLOAD) throw new IOException("Invalid ADB payload length: " + len);
        byte[] data = new byte[len];
        in.readFully(data);
        if (sum != 0 && checksum(data) != sum) {
            throw new IOException("ADB payload checksum mismatch");
        }
        return new Packet(cmd, arg0, arg1, data);
    }

    private static final class Packet {
        final int cmd, arg0, arg1;
        final byte[] data;
        Packet(int c, int a0, int a1, byte[] d) { cmd = c; arg0 = a0; arg1 = a1; data = d; }
    }

    public void connect(String host, int port, AdbIdentity id, ShellListener l) throws Exception {
        listener = l;
        socket = new Socket();
        socket.setTcpNoDelay(true);
        socket.connect(new InetSocketAddress(host, port), 7000);
        socket.setSoTimeout(AUTH_TIMEOUT_MS);
        in = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
        out = new DataOutputStream(new BufferedOutputStream(socket.getOutputStream()));

        send(A_CNXN, A_VERSION, MAX_PAYLOAD, "host::".getBytes(StandardCharsets.UTF_8));

        boolean sentPublicKey = false;
        boolean connected = false;
        int signatures = 0;
        while (!connected) {
            Packet p = readPacket();
            if (p.cmd == A_CNXN) {
                connected = true;
                break;
            }
            if (p.cmd != A_AUTH) throw new IOException("Unexpected ADB packet: " + commandName(p.cmd));
            if (p.arg0 != 1) throw new IOException("Unexpected AUTH type: " + p.arg0);

            if (signatures == 0) {
                send(A_AUTH, 2, 0, id.sign(p.data));
                signatures++;
            } else if (!sentPublicKey) {
                send(A_AUTH, 3, 0, id.publicKeyWire());
                sentPublicKey = true;
            } else {
                throw new IOException("ADB authentication needs approval on the target; approve the RSA key and reconnect");
            }
        }

        socket.setSoTimeout(0);
        if (listener != null) listener.onOutput("connected to " + host + ":" + port + "\n");
        openInteractiveShell();
    }

    private void openInteractiveShell() throws IOException {
        byte[] service = "shell,v2,pty,TERM=dumb:".getBytes(StandardCharsets.UTF_8);
        send(A_OPEN, localId, 0, service);
        Packet p = readPacket();
        if (p.cmd == A_OKAY) {
            remoteId = p.arg0;
            shellOpen = true;
            writeReady = true;
            startReader();
            return;
        }
        if (p.cmd == A_CLSE) throw new IOException("Target rejected interactive shell");
        throw new IOException("Expected OKAY, got " + commandName(p.cmd));
    }

    private static int le32(byte[] b, int off) {
        return (b[off] & 255) | ((b[off + 1] & 255) << 8)
                | ((b[off + 2] & 255) << 16) | ((b[off + 3] & 255) << 24);
    }

    private void startReader() {
        readerThread = new Thread(() -> {
            try {
                while (shellOpen) {
                    Packet p = readPacket();
                    if (p.cmd == A_OKAY) {
                        // Remote ACK for a host->device WRTE. This is the
                        // transport flow-control event that makes repeated
                        // commands reliable on modern Android/adbd.
                        if (p.arg1 == localId) {
                            synchronized (this) {
                                writeReady = true;
                                notifyAll();
                            }
                        }
                    } else if (p.cmd == A_WRTE && p.arg1 == localId) {
                        if (p.data.length >= 5) {
                            int streamId = p.data[0] & 255;
                            int len = le32(p.data, 1);
                            int n = Math.min(Math.max(len, 0), p.data.length - 5);
                            if (n > 0 && (streamId == SHELL_STDOUT || streamId == SHELL_STDERR)) {
                                String text = new String(p.data, 5, n, StandardCharsets.UTF_8);
                                if (streamId == SHELL_STDERR) {
                                    if (listener != null) listener.onError(text);
                                } else if (listener != null) {
                                    listener.onOutput(text);
                                }
                            } else if (streamId == SHELL_EXIT && listener != null) {
                                listener.onOutput("\n[exit " + (n > 0 ? (p.data[5] & 255) : 0) + "]\n");
                            }
                        }
                        send(A_OKAY, localId, p.arg0, new byte[0]);
                    } else if (p.cmd == A_CLSE) {
                        shellOpen = false;
                        synchronized (this) {
                            writeReady = false;
                            notifyAll();
                        }
                        try { send(A_CLSE, localId, p.arg0, new byte[0]); } catch (Exception ignored) {}
                        break;
                    }
                }
            } catch (Exception e) {
                if (shellOpen && listener != null) {
                    listener.onError("[ADB transport] " + errorText(e) + "\n");
                }
            } finally {
                shellOpen = false;
                synchronized (this) {
                    writeReady = false;
                    notifyAll();
                }
                if (listener != null) listener.onClosed();
            }
        }, "ArulShell-ADB-Reader");
        readerThread.start();
    }

    /** Send one shell-v2 stdin packet and wait for ADB WRTE flow-control ACK. */
    public synchronized void writeShell(byte[] data) throws IOException {
        if (!shellOpen) throw new IOException("Shell is not connected");
        if (data == null) throw new IOException("Input is null");
        if (data.length > MAX_PAYLOAD - 5) throw new IOException("Shell input too large");

        long deadline = System.currentTimeMillis() + 5000L;
        while (!writeReady && shellOpen) {
            long left = deadline - System.currentTimeMillis();
            if (left <= 0) throw new IOException("ADB shell is busy or not accepting input");
            try { wait(left); } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new IOException("Interrupted while sending shell input", e);
            }
        }
        if (!shellOpen) throw new IOException("Shell closed while sending input");

        byte[] payload = new byte[data.length + 5];
        payload[0] = SHELL_STDIN;
        int n = data.length;
        payload[1] = (byte) n;
        payload[2] = (byte) (n >>> 8);
        payload[3] = (byte) (n >>> 16);
        payload[4] = (byte) (n >>> 24);
        System.arraycopy(data, 0, payload, 5, data.length);
        writeReady = false;
        try {
            send(A_WRTE, localId, remoteId, payload);
        } catch (IOException e) {
            writeReady = false;
            throw new IOException("ADB shell write failed: " + errorText(e), e);
        }
    }

    public void writeShell(String text) throws IOException {
        writeShell(text.getBytes(StandardCharsets.UTF_8));
    }

    private static String errorText(Throwable e) {
        String m = e.getMessage();
        return e.getClass().getSimpleName() + (m == null || m.isEmpty() ? "" : ": " + m);
    }

    @Override public synchronized void close() throws IOException {
        shellOpen = false;
        writeReady = false;
        notifyAll();
        if (socket != null) socket.close();
    }
}
