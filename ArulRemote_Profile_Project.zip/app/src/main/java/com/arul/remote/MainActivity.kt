package com.arul.remote

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : AppCompatActivity() {
    private lateinit var output: TextView
    private lateinit var input: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        output = findViewById(R.id.output)
        input = findViewById(R.id.input)

        output.text = "Arul Remote\nLocal terminal ready.\n\n"

        findViewById<Button>(R.id.runButton).setOnClickListener {
            runShell(input.text.toString(), false)
        }
        findViewById<Button>(R.id.rootButton).setOnClickListener {
            runShell(input.text.toString(), true)
        }
        findViewById<Button>(R.id.clearButton).setOnClickListener {
            output.text = ""
        }
    }

    private fun runShell(command: String, root: Boolean) {
        if (command.isBlank()) return
        output.append("\n$ ${if (root) "su -c " else ""}$command\n")
        Thread {
            try {
                val process = if (root)
                    Runtime.getRuntime().exec(arrayOf("su", "-c", command))
                else
                    Runtime.getRuntime().exec(arrayOf("sh", "-c", command))

                val reader = BufferedReader(InputStreamReader(process.inputStream))
                val error = BufferedReader(InputStreamReader(process.errorStream))
                val text = StringBuilder()
                reader.forEachLine { text.append(it).append('\n') }
                error.forEachLine { text.append(it).append('\n') }
                process.waitFor()
                runOnUiThread { output.append(text.toString()) }
            } catch (e: Exception) {
                runOnUiThread { output.append("Error: ${e.message}\n") }
            }
        }.start()
    }
}
