plugins {
    id("com.android.application")
}

android {
    namespace = "com.arul.remote"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.arul.remote"
        minSdk = 26
        targetSdk = 35
        versionCode = 5
        versionName = "1.4-direct-adb-java"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.core:core:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.activity:activity-ktx:1.10.0")
}
