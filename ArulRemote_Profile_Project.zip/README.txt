Arul Remote Direct ADB v1.2 BUILD FIX

Perbaikan:
- compileSdk diturunkan ke 35 agar tidak bergantung pada Android SDK 37 yang
  mungkin belum tersedia di runner GitHub Actions.
- memakai artifact Android resmi Kadb: com.flyfishxu:kadb-android:2.1.4.
- INTERNET permission ditambahkan untuk koneksi TCP ke adbd.
- Run/Send tetap menggunakan Direct ADB: tidak memakai sh, Termux, atau adb binary.

Pemakaian:
1. Upload ZIP ini sesuai nama yang diminta workflow.
2. Jalankan Build APK.
3. Di aplikasi masukkan:
   adb connect IP:PORT
4. Tekan Run.

Catatan:
Wireless debugging Android 11+ dapat memerlukan pairing terlebih dahulu dan
port yang tampil tidak selalu 5555.
