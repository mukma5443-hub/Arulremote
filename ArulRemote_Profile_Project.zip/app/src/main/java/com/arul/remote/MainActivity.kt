package com.arul.remote

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.flyfishxu.kadb.Kadb
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : AppCompatActivity() {
    private lateinit var output: TextView
    private lateinit var input: EditText

    @Volatile
    private var lastHost: String? = null

    @Volatile
    private var lastPort: Int? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        output = findViewById(R.id.output)
        input = findViewById(R.id.input)

        output.text = "Arul Remote\nDirect ADB client ready.\nNo Termux / android-tools required.\n\n"

        findViewById<Button>(R.id.runButton).setOnClickListener {
            runCommand(input.text.toString(), false)
        }
        findViewById<Button>(R.id.rootButton).setOnClickListener {
            runCommand(input.text.toString(), true)
        }
        findViewById<Button>(R.id.clearButton).setOnClickListener {
            output.text = ""
        }
    }

    private fun runCommand(command: String, root: Boolean) {
        if (command.isBlank()) return

        appendOutput("\n$ ${if (root) "su -c " else ""}$command\n")

        Thread {
            try {
                if (!root && handleDirectAdb(command)) {
                    return@Thread
                }

                val process = if (root) {
                    Runtime.getRuntime().exec(arrayOf("su", "-c", command))
                } else {
                    Runtime.getRuntime().exec(arrayOf("sh", "-c", command))
                }

                val reader = BufferedReader(InputStreamReader(process.inputStream))
                val error = BufferedReader(InputStreamReader(process.errorStream))
                val text = StringBuilder()
                reader.forEachLine { text.append(it).append('\n') }
                error.forEachLine { text.append(it).append('\n') }
                process.waitFor()

                appendOutput(text.toString())
            } catch (e: Exception) {
                appendOutput("Error: ${e.message}\n")
            }
        }.start()
    }

    /**
     * Handles the useful ADB-over-network commands directly inside the APK.
     *
     * Examples:
     *   adb connect 192.168.1.8:5555
     *   adb shell getprop ro.product.model
     *   adb shell settings get system screen_brightness
     *
     * This does not launch /system/bin/adb or a Termux command.
     */
    private fun handleDirectAdb(command: String): Boolean {
        val trimmed = command.trim()

        val connect = Regex("""^adb\\s+connect\\s+([^:\\s]+):(\\d+)\\s*$""")
            .find(trimmed)

        if (connect != null) {
            val host = connect.groupValues[1]
            val port = connect.groupValues[2].toInt()

            try {
                Kadb.create(host, port).use { adb ->
                    val response = adb.shell("echo ARUL_REMOTE_CONNECTED")
                    if (response.exitCode == 0) {
                        lastHost = host
                        lastPort = port
                        appendOutput("connected to $host:$port\n")
                        appendOutput(response.output)
                    } else {
                        appendOutput("connect failed ($host:$port)\n")
                        appendOutput(response.output)
                    }
                }
            } catch (e: Exception) {
                appendOutput(
                    "ADB connect error: ${e.message}\n" +
                    "Pastikan Wireless debugging sudah aktif dan perangkat sudah dipair/diizinkan.\n"
                )
            }
            return true
        }

        val shell = Regex("""^adb\\s+shell\\s+(.+)$""", RegexOption.DOT_MATCHES_ALL)
            .find(trimmed)

        if (shell != null) {
            val host = lastHost
            val port = lastPort

            if (host == null || port == null) {
                appendOutput("Belum terhubung. Jalankan: adb connect IP:PORT\n")
                return true
            }

            try {
                Kadb.create(host, port).use { adb ->
                    val response = adb.shell(shell.groupValues[1])
                    appendOutput(response.output)
                    if (response.exitCode != 0) {
                        appendOutput("exit code: ${response.exitCode}\n")
                    }
                }
            } catch (e: Exception) {
                appendOutput("ADB shell error: ${e.message}\n")
            }
            return true
        }

        // Convenience command: connect IP:PORT
        val shortConnect = Regex("""^connect\\s+([^:\\s]+):(\\d+)\\s*$""")
            .find(trimmed)

        if (shortConnect != null) {
            return handleDirectAdb(
                "adb connect ${shortConnect.groupValues[1]}:${shortConnect.groupValues[2]}"
            )
        }

        return false
    }

    private fun appendOutput(text: String) {
        runOnUiThread {
            output.append(text)
        }
    }
}
