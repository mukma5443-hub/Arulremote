ArulShell FIX 4

Alpine-style Android terminal with built-in ADB.

FIX 4 changes:
- adb shell now opens one persistent interactive shell stream using shell:
- shell stdin is kept open and commands are written to the same stream
- shell stdout/stderr are continuously read in the background
- exit closes the persistent shell and returns to localhost prompt
- adb connect / adb pair remain built into the app

No Termux, pkg update, or android-tools package is required by the app.
