package com.arul.remote

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.flyfishxu.kadb.Kadb

class MainActivity : AppCompatActivity() {
    private lateinit var output: TextView
    private lateinit var input: EditText

    @Volatile private var host: String? = null
    @Volatile private var port: Int = 5555

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        output = findViewById(R.id.output)
        input = findViewById(R.id.input)

        output.text = "Arul Remote\nDirect ADB mode — no sh / Termux / adb binary.\n\n"

        findViewById<Button>(R.id.runButton).setOnClickListener {
            execute(input.text.toString().trim())
        }
        findViewById<Button>(R.id.rootButton).setOnClickListener {
            execute(input.text.toString().trim())
        }
        findViewById<Button>(R.id.clearButton).setOnClickListener {
            output.text = ""
        }
    }

    private fun execute(command: String) {
        if (command.isBlank()) return
        Thread {
            try {
                val connect = Regex("""^(?:adb\s+)?connect\s+([^:\s]+):(\d+)\s*$""").find(command)
                if (connect != null) {
                    val h = connect.groupValues[1]
                    val p = connect.groupValues[2].toInt()
                    Kadb.create(h, p).use { adb ->
                        val response = adb.shell("echo ARUL_REMOTE_CONNECTED")
                        if (response.exitCode == 0) {
                            host = h
                            port = p
                            append("connected to $h:$p\n")
                        } else {
                            append("connect failed to $h:$p\n${response.output}\n")
                        }
                    }
                    return@Thread
                }

                val h = host
                if (h == null) {
                    append("Belum terhubung. Ketik: adb connect IP:5555\n")
                    return@Thread
                }

                val actual = command.removePrefix("adb shell ").removePrefix("adb shell")
                    .trim()
                if (actual.isBlank()) {
                    append("Masukkan perintah ADB shell. Contoh: getprop ro.product.model\n")
                    return@Thread
                }

                Kadb.create(h, port).use { adb ->
                    val response = adb.shell(actual)
                    append(response.output)
                    if (response.exitCode != 0) {
                        append("exit code: ${response.exitCode}\n")
                    }
                }
            } catch (e: Exception) {
                append("ADB error: ${e.message}\n")
            }
        }.start()
    }

    private fun append(text: String) {
        runOnUiThread { output.append(text) }
    }
}
