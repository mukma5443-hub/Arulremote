# ArulShell FIX 6.2.2

Perbaikan untuk kasus FIX 6.2.1 yang menampilkan `[WRITE ERROR] null` saat mengetik `su`.

Perubahan utama:
- Tetap memakai ADB TCP langsung dan `shell,v2,pty` agar shell interaktif.
- Memperbaiki flow-control WRTE/OKAY: input host menunggu ACK ADB sebelum input berikutnya dikirim.
- Reader menangani paket `OKAY` dari adbd dan membangunkan penulis input.
- Error write sekarang menampilkan tipe exception sehingga tidak lagi hanya `[WRITE ERROR] null`.
- Tidak menjalankan `whoami`, `pwd`, `ls`, atau perintah otomatis.
- Setelah tersambung, pengguna dapat mengetik `su`, Enter, lalu melanjutkan perintah dalam shell yang sama.

Alur:

    adb connect IP:5555
        -> adb shell
        -> ketik su
        -> shell root jika perangkat/KernelSU mengizinkannya

Catatan: aplikasi tidak dapat melewati otorisasi RSA Android. Key aplikasi disimpan agar reconnect berikutnya memakai identity yang sama setelah key tersebut dipercaya oleh target.
