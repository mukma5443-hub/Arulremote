ArulShell v3 — Alpine-style terminal

This project changes the interface into a fullscreen terminal inspired by the Alpine/iSH-style screen shown by the user.

Built-in commands:
  adb pair IP:PORT CODE
  adb connect IP:PORT
  adb shell
  adb shell COMMAND
  exit
  clear
  history
  pwd / ls / id / uname (where Android permits)

ADB is implemented in-app; this project does not require Termux, pkg update, pkg install android-tools, or an adb executable on the device running ArulShell.

Important: Android Wireless Debugging normally has a separate pairing port and connect port. Pair first, then use the current connect port shown by Wireless debugging.

The UI is an Alpine-style terminal approximation; it is not a full Alpine Linux userspace. Commands run through Android APIs or the integrated ADB client.
