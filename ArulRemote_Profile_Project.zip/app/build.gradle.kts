plugins { id("com.android.application") }

android { namespace = "com.arul.shell"; compileSdk = 35
    defaultConfig { applicationId = "com.arul.shell"; minSdk = 26; targetSdk = 35; versionCode = 2; versionName = "2.0-arulshell-adb-pairing" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}

dependencies {
    implementation("androidx.core:core:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("com.github.osservatorionessuno:libadb-android-bc:3.2.0")
    implementation("org.bouncycastle:bcprov-jdk15to18:1.84")
    implementation("org.bouncycastle:bcpkix-jdk15to18:1.84")
}
