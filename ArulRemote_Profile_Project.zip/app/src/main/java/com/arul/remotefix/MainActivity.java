package com.arul.remotefix;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.widget.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private EditText ip, port, command;
    private TextView log;
    private Button connect, send;
    private final ExecutorService pool = Executors.newSingleThreadExecutor();
    private volatile AdbTransport transport;
    private static final int REQ_NEARBY = 701;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18,18,18,18);

        TextView title = new TextView(this);
        title.setText("ArulShell FIX 6.2\nADB connect IP:5555 → adb shell");
        title.setTextSize(20); title.setTextColor(Color.WHITE);
        title.setPadding(12,12,12,12);
        title.setBackgroundColor(Color.rgb(25,25,25));
        root.addView(title);

        ip = new EditText(this); ip.setHint("IP HP target"); root.addView(ip);
        port = new EditText(this); port.setText("5555"); root.addView(port);

        connect = new Button(this); connect.setText("CONNECT + SHELL"); root.addView(connect);

        log = new TextView(this);
        log.setTextIsSelectable(true);
        log.setTextSize(15);
        log.setTypeface(android.graphics.Typeface.MONOSPACE);
        ScrollView scroll = new ScrollView(this); scroll.addView(log);
        root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));

        command = new EditText(this);
        command.setHint("Ketik perintah shell lalu Enter");
        command.setSingleLine(true);
        command.setImeOptions(EditorInfo.IME_ACTION_SEND);
        root.addView(command);
        send = new Button(this); send.setText("SEND"); send.setEnabled(false); root.addView(send);
        setContentView(root);

        connect.setOnClickListener(v -> connect());
        send.setOnClickListener(v -> sendCommand());
        command.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                sendCommand(); return true;
            }
            return false;
        });
    }

    private void connect() {
        final String h = ip.getText().toString().trim();
        final String ps = port.getText().toString().trim();
        if (h.isEmpty()) { log.setText("Masukkan IP HP target.\n"); return; }
        final int p;
        try { p = Integer.parseInt(ps); } catch (Exception e) { log.setText("Port tidak valid.\n"); return; }
        if (p < 1 || p > 65535) { log.setText("Port tidak valid.\n"); return; }

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.NEARBY_WIFI_DEVICES}, REQ_NEARBY);
        }

        connect.setEnabled(false);
        send.setEnabled(false);
        log.setText("adb connect " + h + ":" + p + "\n");

        pool.execute(() -> {
            try {
                AdbIdentity id = AdbIdentity.loadOrCreate(this);
                AdbTransport a = new AdbTransport();
                transport = a;
                a.connect(h, p, id, new AdbTransport.ShellListener() {
                    @Override public void onOutput(String text) { append(text); }
                    @Override public void onError(String text) { append("\n[ADB ERROR] " + text + "\n"); }
                    @Override public void onClosed() { ui(() -> send.setEnabled(false)); }
                });
                ui(() -> {
                    send.setEnabled(true);
                    command.requestFocus();
                });
            } catch (Exception e) {
                String msg = e.getMessage() == null ? e.toString() : e.getMessage();
                if (msg.contains("ECONNREFUSED")) {
                    msg += "\nPort 5555 tidak menerima ADB TCP. USB Debugging ON saja belum cukup.";
                } else if (msg.contains("EHOSTUNREACH") || msg.contains("No route")) {
                    msg += "\nTidak ada route ke IP target. Pastikan kedua HP benar-benar satu LAN/Wi-Fi.";
                } else if (msg.contains("EPERM") || msg.contains("Operation not permitted")) {
                    msg += "\nAkses jaringan lokal ditolak Android. Izinkan 'Perangkat di sekitar/Nearby devices' untuk ArulShell.";
                }
                append("Gagal: " + msg + "\n");
            } finally {
                ui(() -> connect.setEnabled(true));
            }
        });
    }

    private void sendCommand() {
        String s = command.getText().toString();
        if (s.isEmpty()) return;
        try {
            AdbTransport a = transport;
            if (a == null) throw new IllegalStateException("Belum terhubung");
            a.writeShell(s + "\n");
            command.setText("");
        } catch (Exception e) {
            append("\n[WRITE ERROR] " + e.getMessage() + "\n");
        }
    }

    private void append(String x) { ui(() -> { log.append(x); }); }
    private void ui(Runnable r) { runOnUiThread(r); }

    @Override protected void onDestroy() {
        try { if (transport != null) transport.close(); } catch (Exception ignored) {}
        pool.shutdownNow();
        super.onDestroy();
    }
}
