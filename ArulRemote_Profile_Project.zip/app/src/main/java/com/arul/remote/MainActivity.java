package com.arul.remote;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private TextView output;
    private EditText input;
    private Button runButton;
    private Button sendButton;

    private volatile String connectedHost;
    private volatile int connectedPort = 5555;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        output = findViewById(R.id.output);
        input = findViewById(R.id.input);
        runButton = findViewById(R.id.runButton);
        sendButton = findViewById(R.id.rootButton);

        runButton.setEnabled(true);
        sendButton.setEnabled(true);

        output.setText("Arul Remote\n" +
                "Direct ADB TCP mode — no sh / Termux / adb binary.\n\n" +
                "Contoh:\n" +
                "adb connect 172.20.10.2:5555\n");

        runButton.setOnClickListener(v -> connectCommand(input.getText().toString()));
        sendButton.setOnClickListener(v -> shellCommand(input.getText().toString()));
        findViewById(R.id.clearButton).setOnClickListener(v -> output.setText(""));
    }

    private void connectCommand(String raw) {
        final String command = raw.trim();
        final String[] target = parseConnect(command);
        if (target == null) {
            append("Format salah. Contoh: adb connect 172.20.10.2:5555\n");
            return;
        }

        final String host = target[0];
        final int port;
        try {
            port = Integer.parseInt(target[1]);
            if (port < 1 || port > 65535) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            append("Port tidak valid.\n");
            return;
        }

        setBusy(true);
        append("Menghubungkan langsung ke " + host + ":" + port + " ...\n");

        new Thread(() -> {
            try (AdbConnection adb = AdbConnection.connect(host, port)) {
                connectedHost = host;
                connectedPort = port;
                append("CONNECTED: " + host + ":" + port + "\n");
                append("Direct ADB berhasil — tanpa sh, Termux, atau binary adb.\n");
            } catch (Exception e) {
                append("CONNECT FAILED: " + e.getClass().getSimpleName() + ": " +
                        (e.getMessage() == null ? "unknown error" : e.getMessage()) + "\n");
                append("Pastikan IP:PORT benar dan ADB/Wireless debugging aktif.\n");
            } finally {
                setBusy(false);
            }
        }).start();
    }

    private void shellCommand(String raw) {
        String command = raw.trim();
        if (command.startsWith("adb shell ")) command = command.substring(10).trim();
        if (command.equals("adb shell")) command = "";
        if (command.isEmpty()) {
            append("Contoh: getprop ro.product.model\n");
            return;
        }

        final String host = connectedHost;
        final int port = connectedPort;
        if (host == null) {
            append("Belum terhubung. Jalankan adb connect IP:PORT terlebih dahulu.\n");
            return;
        }

        final String shell = command;
        setBusy(true);
        new Thread(() -> {
            try (AdbConnection adb = AdbConnection.connect(host, port)) {
                append(adb.shell(shell));
            } catch (Exception e) {
                append("ADB SHELL ERROR: " + e.getClass().getSimpleName() + ": " +
                        (e.getMessage() == null ? "unknown error" : e.getMessage()) + "\n");
            } finally {
                setBusy(false);
            }
        }).start();
    }

    private static String[] parseConnect(String command) {
        String s = command.trim();
        if (s.regionMatches(true, 0, "adb connect", 0, 11)) {
            s = s.substring(11).trim();
        } else if (s.regionMatches(true, 0, "connect", 0, 7)) {
            s = s.substring(7).trim();
        } else {
            return null;
        }
        int colon = s.lastIndexOf(':');
        if (colon <= 0 || colon == s.length() - 1) return null;
        String host = s.substring(0, colon).trim();
        String port = s.substring(colon + 1).trim();
        if (host.isEmpty() || port.isEmpty() || host.contains(" ") || port.contains(" ")) return null;
        return new String[]{host, port};
    }

    private void setBusy(boolean busy) {
        runOnUiThread(() -> {
            runButton.setEnabled(!busy);
            sendButton.setEnabled(!busy);
        });
    }

    private void append(String text) {
        runOnUiThread(() -> output.append(text));
    }

    /** Minimal ADB host protocol client. No adb executable/server is used. */
    private static final class AdbConnection implements AutoCloseable {
        private static final int CNXN = 0x4e584e43;
        private static final int AUTH = 0x48545541;
        private static final int OPEN = 0x4e45504f;
        private static final int OKAY = 0x59414b4f;
        private static final int WRTE = 0x45545257;
        private static final int CLSE = 0x45534c43;
        private static final int ADB_VERSION = 0x01000000;
        private static final int MAX_DATA = 1024 * 1024;

        private final Socket socket;
        private final BufferedInputStream in;
        private final BufferedOutputStream out;
        private int localId = 1;

        private AdbConnection(Socket socket) throws IOException {
            this.socket = socket;
            this.in = new BufferedInputStream(socket.getInputStream());
            this.out = new BufferedOutputStream(socket.getOutputStream());
        }

        static AdbConnection connect(String host, int port) throws IOException {
            Socket socket = new Socket();
            socket.connect(new InetSocketAddress(host, port), 8000);
            socket.setSoTimeout(8000);
            AdbConnection adb = new AdbConnection(socket);
            try {
                String banner = "host::features=shell_v2,cmd\0";
                adb.send(CNXN, ADB_VERSION, MAX_DATA, banner.getBytes(StandardCharsets.UTF_8));
                Packet p = adb.readPacket();
                if (p.command == AUTH) {
                    throw new IOException("Target requires ADB authentication/pairing; direct legacy TCP 5555 is not available");
                }
                if (p.command != CNXN) {
                    throw new IOException(String.format(Locale.US, "Unexpected ADB response 0x%08x", p.command));
                }
                return adb;
            } catch (IOException e) {
                try { adb.close(); } catch (Exception ignored) {}
                throw e;
            }
        }

        String shell(String command) throws IOException {
            int local = localId++;
            String service = "shell:" + command + "\0";
            send(OPEN, local, 0, service.getBytes(StandardCharsets.UTF_8));
            StringBuilder result = new StringBuilder();
            boolean opened = false;
            while (true) {
                Packet p = readPacket();
                if (p.command == OKAY) {
                    opened = true;
                    if (p.arg0 != local) continue;
                } else if (p.command == WRTE) {
                    if (p.arg1 != local) continue;
                    result.append(new String(p.data, StandardCharsets.UTF_8));
                    send(OKAY, local, p.arg0, new byte[0]);
                } else if (p.command == CLSE) {
                    if (p.arg1 == local || p.arg0 == local) break;
                } else {
                    break;
                }
            }
            if (opened) {
                try { send(CLSE, local, 0, new byte[0]); } catch (IOException ignored) {}
            }
            return result.toString();
        }

        private void send(int command, int arg0, int arg1, byte[] data) throws IOException {
            int length = data.length;
            writeLe(command); writeLe(arg0); writeLe(arg1); writeLe(length);
            writeLe(checksum(data)); writeLe(command ^ 0xffffffff);
            out.write(data);
            out.flush();
        }

        private Packet readPacket() throws IOException {
            int command = readLe();
            int arg0 = readLe();
            int arg1 = readLe();
            int length = readLe();
            int checksum = readLe();
            int magic = readLe();
            if (magic != (command ^ 0xffffffff)) throw new IOException("Invalid ADB packet magic");
            if (length < 0 || length > MAX_DATA) throw new IOException("Invalid ADB packet length: " + length);
            byte[] data = new byte[length];
            readFully(data);
            if (checksum(data) != checksum) throw new IOException("Invalid ADB packet checksum");
            return new Packet(command, arg0, arg1, data);
        }

        private int checksum(byte[] data) {
            int sum = 0;
            for (byte b : data) sum = (sum + (b & 0xff)) & 0xffffffff;
            return sum;
        }

        private void writeLe(int value) throws IOException {
            out.write(value & 0xff);
            out.write((value >>> 8) & 0xff);
            out.write((value >>> 16) & 0xff);
            out.write((value >>> 24) & 0xff);
        }

        private int readLe() throws IOException {
            int b0 = in.read(), b1 = in.read(), b2 = in.read(), b3 = in.read();
            if ((b0 | b1 | b2 | b3) < 0) throw new EOFException("ADB connection closed");
            return b0 | (b1 << 8) | (b2 << 16) | (b3 << 24);
        }

        private void readFully(byte[] data) throws IOException {
            int off = 0;
            while (off < data.length) {
                int n = in.read(data, off, data.length - off);
                if (n < 0) throw new EOFException("ADB connection closed");
                off += n;
            }
        }

        @Override public void close() throws IOException { socket.close(); }

        private static final class Packet {
            final int command, arg0, arg1; final byte[] data;
            Packet(int command, int arg0, int arg1, byte[] data) {
                this.command = command; this.arg0 = arg0; this.arg1 = arg1; this.data = data;
            }
        }
    }
}
