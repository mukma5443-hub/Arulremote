Arul Remote Direct ADB v1.1 FIXED

Perbaikan:
- Tombol Run/Send dipastikan enabled dan clickable.
- Koneksi memakai Kadb langsung, tanpa sh, Termux, atau binary adb.
- Versi Kadb diperbarui ke 2.1.4.
- Pesan koneksi/error dibuat lebih jelas.

Cara pakai:
1. Build/install APK dari project.
2. Di HP target aktifkan ADB/Wireless debugging.
3. Pastikan IP dan port target benar.
4. Masukkan:
   adb connect IP:PORT
5. Tekan Run.
6. Jika berhasil akan muncul CONNECTED: IP:PORT.

Catatan:
- Jika Android target memakai Wireless debugging dengan pairing, lakukan pairing terlebih dahulu.
- Port Wireless debugging tidak selalu 5555.
