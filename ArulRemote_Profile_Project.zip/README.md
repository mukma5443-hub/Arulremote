# ArulShell FIX 6.2 — direct ADB shell

Target flow:

```text
adb connect IP:5555
adb shell
```

The app now:
- sends a length-correct ADB CNXN packet (no stray NUL in the payload);
- performs ADB AUTH with one persistent RSA-2048 identity;
- signs the first AUTH token and sends the public key only after the next token, matching the normal ADB host flow;
- keeps the RSA identity in app-private storage for reconnects;
- opens `shell,v2,pty,TERM=dumb:` without a command, so the target gives an interactive shell prompt;
- frames stdin using the shell-v2 protocol instead of sending raw bytes;
- forwards stdout/stderr continuously and acknowledges ADB WRTE packets;
- does not run `whoami`, `pwd`, `ls`, or any automatic test command.

The first time the target has not trusted this app's key, Android may show the RSA authorization dialog. After the same key is trusted, reconnects reuse the same identity.

The target must already expose `adbd` on TCP port 5555. USB Debugging being ON by itself does not guarantee that port 5555 is listening.

On Android 16 builds where local-network protection is enabled for the app, allow ArulShell's Nearby devices/local-network access. The manifest declares `NEARBY_WIFI_DEVICES` for this case.
